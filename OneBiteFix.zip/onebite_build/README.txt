ONE BITE – CUSTOMER APP + RESTAURANT PARTNER DASHBOARD
=====================================================

This is a fresh responsive PWA starter package. It contains two separate experiences:
- index.html: customer ordering app
- owner.html: owner/staff partner dashboard (mobile + desktop responsive)

Firebase project configuration and the owner UID supplied in the conversation are prefilled in firebase.js.

IMPORTANT SETUP BEFORE DEPLOYING
--------------------------------
1. In Firebase Console, open Firestore Database > Rules.
2. Review firestore.rules carefully and publish it. It allows public customer order creation and public menu/table/settings reads; owner-only management; staff dashboard access for UIDs manually added by the owner. Public order creation is a basic starter design and should be hardened before a high-volume public launch (ideally validate menu prices and order totals in a trusted backend/Cloud Function and add App Check / abuse controls).
3. Keep Email/Password sign-in enabled in Firebase Authentication.
4. Owner login is the Firebase account whose UID is configured as OWNER_UID in firebase.js. Never share the owner's password.
5. To add staff: create their user in Firebase Authentication, copy their UID, then sign in as owner and add that UID in Staff Access. Staff can view/manage orders; only the owner can edit menu, tables and settings.
6. Deploy the ENTIRE contents of this folder to Netlify (not just one HTML file). The customer app URL is the site's root. The owner dashboard URL is /owner.html.
7. For each table, open Tables & QR > Create 10 tables. The customer QR links open the customer app with the table preselected. QR image generation currently uses the QR Server image endpoint and needs internet access.

CURRENT FEATURES
----------------
Customer: menu/category browsing, cart, delivery/pickup/dine-in, table preselection via QR, fixed configurable delivery charge (default ₹40 for delivery only), cash payment selection, Firestore order creation, WhatsApp order summary.
Owner dashboard: Firebase login and UID authorization; overview metrics; live Firestore order feed; status changes; order history; 10 table records and QR links; menu add/edit/delete; restaurant profile; delivery charge; sales summary and CSV export; staff UID access management.

NOTES / LIMITATIONS
-------------------
- This is a web-installable PWA, not a signed Android APK or Play Store release.
- This package is a new build and has not been deployed to your Netlify site from here. Test it in a separate Netlify deploy before replacing your current live site.
- Default menu items are fallback sample data in the customer interface until menuItems are added to Firestore. To manage a live menu, add items from Owner > Menu Management.
- No payment gateway / UPI integration is included. Cash payment options only.
- Sales report currently summarizes the orders available in Firestore; date-range filtering can be added later.
- Staff account creation itself must be done in Firebase Authentication; the dashboard grants/revokes app-level access by UID.
