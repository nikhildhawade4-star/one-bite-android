import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
export const firebaseConfig={apiKey:'AIzaSyAB-HK2wYkSWbRku8izKHWdOrjh45bwgjE',authDomain:'one-bite-f388a.firebaseapp.com',projectId:'one-bite-f388a',storageBucket:'one-bite-f388a.firebasestorage.app',messagingSenderId:'150170495515',appId:'1:150170495515:web:347ccda44e6a93d3c0a6be'};
export const app=initializeApp(firebaseConfig);export const auth=getAuth(app);export const db=getFirestore(app);
export const OWNER_UID='u3QFPrfH3SXDmpyBaGMkl1fI6XA3';
