# One Bite Android-ready ordering app

This is an installable Progressive Web App (PWA) starter for One Bite. It is designed for Android phones and includes:
- Veg sandwich, pizza, sides and drinks menu
- Cart and customer checkout\n- Cash on Pickup / Cash on Delivery payment selection\n- UPI shown as Coming Soon until a business UPI ID/payment provider is configured
- WhatsApp order handoff to **+91 7276022026**
- Owner dashboard with order statuses and CSV export
- PWA manifest and offline shell

## Important: what works immediately
- Customers can browse the menu, add items to cart, enter details and open WhatsApp with a pre-filled order.
- Orders are stored in the browser's local storage on the device used to place the order.
- The owner dashboard can view those local demo orders on that same browser/device.

## Required before real public launch
The dashboard cannot receive customer orders from other phones until a shared cloud database is configured. The Firebase integration hook is included in `app.js`, but no Firebase project credentials have been supplied and no cloud service has been deployed.

1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web App and copy its Firebase config object.
3. Enable Realtime Database.
4. Paste the config object into `FIREBASE_CONFIG` in `app.js` (replace `null`).
5. Set secure database rules and implement owner authentication before accepting real customer data. Do not use the demo PIN as production security.
6. Host the folder on an HTTPS host (Firebase Hosting is one option).
7. Open the hosted URL in Chrome on Android, tap the browser menu, then choose **Install app** or **Add to Home screen**.

## Owner PIN
Demo PIN is `7276` in `app.js`. Change it for local testing. A client-side PIN is not secure for a real public app; use Firebase Authentication and server-side/database rules for production.

## Menu pricing
Pizza names and prices are based on the prices provided by the restaurant owner. Other sandwich, sides and beverage prices were carried over from the draft menu poster and should be checked before publishing.

## Business details
One Bite, Kedgaon, Ahilyanagar, Maharashtra 414005  
WhatsApp: +91 72760 22026

## Native APK
This folder is a PWA source package, not a signed Android APK. It can be installed on Android from a secure hosted URL. A native APK requires an Android build/signing workflow.


## PWA installation fix
This updated package includes valid 192x192 and 512x512 PNG icons, a maskable icon,
a completed web app manifest, and a versioned service worker. Upload the contents
of the `one_bite_android_app` folder to the existing Netlify site (replace old files).
Then open the live site in Chrome, refresh it, and try Menu > Install app. If Chrome
still shows the old install status, clear the site's stored data in Chrome settings
and reopen the site. The site must be served over HTTPS.
