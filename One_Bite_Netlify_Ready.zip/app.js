// One Bite ordering app. Add your Firebase web config below to enable cloud order sync.
const WHATSAPP_NUMBER = "917276022026";
const OWNER_PIN = "7276"; // Change this before publishing. Do not rely on a client-side PIN for production security.
const FIREBASE_CONFIG = null; // Paste Firebase web-app config here to sync customer orders to the owner's dashboard.
const menu = [
  {id:"s1",cat:"Sandwiches",name:"Classic Veg Sandwich",price:70,emoji:"🥪",desc:"Fresh vegetables and chutney"},
  {id:"s2",cat:"Sandwiches",name:"Masala Veg Sandwich",price:80,emoji:"🥪",desc:"Spiced vegetable filling"},
  {id:"s3",cat:"Sandwiches",name:"Cheese Veg Sandwich",price:90,emoji:"🧀",desc:"Veggies with melted cheese"},
  {id:"s4",cat:"Sandwiches",name:"Grilled Veg Sandwich",price:100,emoji:"🥪",desc:"Crispy grilled sandwich"},
  {id:"s5",cat:"Sandwiches",name:"Tandoori Veg Sandwich",price:110,emoji:"🔥",desc:"Smoky tandoori flavour"},
  {id:"s6",cat:"Sandwiches",name:"Corn & Cheese Sandwich",price:120,emoji:"🌽",desc:"Sweet corn and cheese"},
  {id:"s7",cat:"Sandwiches",name:"Paneer Tikka Sandwich",price:130,emoji:"🧀",desc:"Paneer tikka filling"},
  {id:"p1",cat:"Pizzas",name:"Margarita Pizza",price:130,emoji:"🍕",desc:"Classic cheese pizza"},
  {id:"p2",cat:"Pizzas",name:"Sweet Corn Pizza",price:140,emoji:"🌽",desc:"Loaded with sweet corn"},
  {id:"p3",cat:"Pizzas",name:"Onion Pizza",price:140,emoji:"🧅",desc:"Onion and cheese topping"},
  {id:"p4",cat:"Pizzas",name:"Paneer Pizza",price:170,emoji:"🍕",desc:"Paneer with delicious toppings"},
  {id:"p5",cat:"Pizzas",name:"Mix Veg Pizza",price:170,emoji:"🍕",desc:"Mixed vegetable topping"},
  {id:"x1",cat:"Sides",name:"French Fries",price:80,emoji:"🍟",desc:"Golden crispy fries"},
  {id:"x2",cat:"Sides",name:"Peri Peri Fries",price:90,emoji:"🍟",desc:"Spicy peri peri seasoning"},
  {id:"x3",cat:"Sides",name:"Cheese Fries",price:110,emoji:"🧀",desc:"Fries with cheesy topping"},
  {id:"x4",cat:"Sides",name:"Extra Cheese",price:20,emoji:"🧀",desc:"Add-on"},
  {id:"x5",cat:"Sides",name:"Extra Sauce",price:15,emoji:"🥫",desc:"Add-on"},
  {id:"d1",cat:"Drinks",name:"Masala Chai",price:15,emoji:"☕",desc:"Indian spiced tea"},
  {id:"d2",cat:"Drinks",name:"Cold Coffee",price:60,emoji:"🥤",desc:"Chilled coffee"},
  {id:"d3",cat:"Drinks",name:"Milkshake",price:70,emoji:"🥤",desc:"Chocolate / Strawberry / Vanilla"},
  {id:"d4",cat:"Drinks",name:"Fresh Lime Soda",price:40,emoji:"🍋",desc:"Refreshing lime soda"}
];
const cart = new Map();
const $ = id => document.getElementById(id);
const money = n => "₹" + n;
let currentCategory = "All";
function renderMenu(){
  $("menuGrid").innerHTML = menu.filter(x=>currentCategory==="All"||x.cat===currentCategory).map(x=>`
    <article class="food-card"><div class="food-emoji">${x.emoji}</div><h3>${x.name}</h3><div class="desc">${x.desc}</div>
    <div class="food-bottom"><span class="price">${money(x.price)}</span><button class="add-btn" data-add="${x.id}">+ Add</button></div></article>`).join("");
}
function renderCart(){
  const rows=[...cart.entries()];
  $("cartCount").textContent=rows.reduce((a,[,q])=>a+q,0);
  if(!rows.length){$("cartItems").innerHTML='<p class="muted">Your cart is empty. Add something delicious!</p>';}
  else $("cartItems").innerHTML=rows.map(([id,q])=>{const x=menu.find(m=>m.id===id);return `<div class="cart-row"><div><b>${x.name}</b><small>${money(x.price)} each</small></div><div class="qty"><button data-minus="${id}">−</button><b>${q}</b><button data-plus="${id}">+</button></div><b>${money(x.price*q)}</b></div>`}).join("");
  $("cartTotal").textContent=money(rows.reduce((a,[id,q])=>a+menu.find(x=>x.id===id).price*q,0));
}
function showToast(msg){$("toast").textContent=msg;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2600)}
$("menuGrid").addEventListener("click",e=>{const id=e.target.dataset.add;if(id){cart.set(id,(cart.get(id)||0)+1);renderCart();showToast("Added to your cart");}});
$("cartItems").addEventListener("click",e=>{const plus=e.target.dataset.plus,minus=e.target.dataset.minus;if(plus)cart.set(plus,(cart.get(plus)||0)+1);if(minus){const q=(cart.get(minus)||0)-1;if(q<=0)cart.delete(minus);else cart.set(minus,q);}renderCart();});
$("tabs").addEventListener("click",e=>{const b=e.target.closest("[data-cat]");if(!b)return;currentCategory=b.dataset.cat;document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t===b));renderMenu();});
$("cartJump").onclick=()=>$("cart").scrollIntoView({behavior:"smooth"});
$("orderType").onchange=()=>{const delivery=$("orderType").value==="Delivery";$("addressWrap").classList.toggle("hidden",!delivery);$("customerAddress").required=delivery;};
function orderText(order){
  return `*NEW ORDER – ONE BITE*\\nOrder ID: ${order.id}\\nName: ${order.name}\\nPhone: ${order.phone}\\nType: ${order.type}\\nPayment: ${order.payment}\\n${order.address?"Address: "+order.address+"\\n":""}\\n${order.items.map(i=>`${i.qty} x ${i.name} – ₹${i.price*i.qty}`).join("\\n")}\\n\\n*Total: ₹${order.total}*\\nNotes: ${order.notes||"None"}`;
}
async function saveCloud(order){
  if(!FIREBASE_CONFIG)return {ok:false,reason:"Cloud sync not configured"};
  try{
    const {initializeApp,getApps}=await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
    const {getDatabase,ref,push}=await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js");
    const app=getApps().length?getApps()[0]:initializeApp(FIREBASE_CONFIG);
    await push(ref(getDatabase(app),"orders"),{...order,createdAt:Date.now(),status:"New"});
    return {ok:true};
  }catch(err){console.error(err);return {ok:false,reason:"Cloud save failed"};}
}
$("checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!cart.size){showToast("Please add items to your cart first");return;}
  const items=[...cart.entries()].map(([id,qty])=>{const x=menu.find(m=>m.id===id);return {id,name:x.name,price:x.price,qty};});
  const order={id:"OB"+Date.now().toString().slice(-8),name:$("customerName").value.trim(),phone:$("customerPhone").value.trim(),type:$("orderType").value,payment:$("paymentMethod").value,address:$("customerAddress").value.trim(),notes:$("notes").value.trim(),items,total:items.reduce((a,x)=>a+x.price*x.qty,0)};
  const cloud=await saveCloud(order);
  const local=JSON.parse(localStorage.getItem("onebite_orders")||"[]");local.unshift({...order,createdAt:Date.now(),status:"New"});localStorage.setItem("onebite_orders",JSON.stringify(local));
  const msg=encodeURIComponent(orderText(order));
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,"_blank");
  showToast(cloud.ok?"Order saved and WhatsApp opened":"WhatsApp opened. Cloud dashboard sync needs setup.");
  cart.clear();renderCart();$("checkoutForm").reset();$("addressWrap").classList.add("hidden");
});
$("adminOpen").onclick=()=>{$("adminModal").classList.remove("hidden");$("adminLogin").classList.remove("hidden");$("dashboard").classList.add("hidden");};
$("adminClose").onclick=()=>$("adminModal").classList.add("hidden");
$("loginBtn").onclick=()=>{if($("adminPin").value!==OWNER_PIN){showToast("Incorrect owner PIN");return;}$("adminLogin").classList.add("hidden");$("dashboard").classList.remove("hidden");loadOrders();};
async function loadOrders(){
  let orders=JSON.parse(localStorage.getItem("onebite_orders")||"[]");
  $("syncStatus").textContent=FIREBASE_CONFIG?"Cloud sync configured; local orders shown here in this starter build.":"Local demo orders only. Add Firebase config to receive orders from other phones.";
  $("ordersList").innerHTML=orders.length?orders.map(o=>`<div class="order-card"><h3>${o.id} · ${money(o.total)}</h3><b>${o.name}</b> · ${o.phone}<p>${o.type}${o.address?"\\n"+o.address:""}\\n${o.items.map(i=>`${i.qty} × ${i.name}`).join("\\n")}\\nNotes: ${o.notes||"None"}</p><small class="muted">${new Date(o.createdAt).toLocaleString()}</small><p>Payment: ${o.payment||"Not specified"}</p><p>Status: <select data-status="${o.id}"><option ${o.status==="New"?"selected":""}>New</option><option ${o.status==="Accepted"?"selected":""}>Accepted</option><option ${o.status==="Preparing"?"selected":""}>Preparing</option><option ${o.status==="Ready"?"selected":""}>Ready</option><option ${o.status==="Completed"?"selected":""}>Completed</option><option ${o.status==="Cancelled"?"selected":""}>Cancelled</option></select></p></div>`).join(""):'<p class="muted">No orders on this device yet.</p>';
}
$("ordersList").addEventListener("change",e=>{const id=e.target.dataset.status;if(!id)return;const orders=JSON.parse(localStorage.getItem("onebite_orders")||"[]");const o=orders.find(x=>x.id===id);if(o)o.status=e.target.value;localStorage.setItem("onebite_orders",JSON.stringify(orders));showToast("Order status updated");});
$("refreshOrders").onclick=loadOrders;
$("exportOrders").onclick=()=>{const data=JSON.parse(localStorage.getItem("onebite_orders")||"[]");const rows=[["Order ID","Name","Phone","Type","Payment","Address","Items","Total","Status","Created"],...data.map(o=>[o.id,o.name,o.phone,o.type,o.payment||"",o.address,o.items.map(i=>`${i.qty}x ${i.name}`).join("; "),o.total,o.status,new Date(o.createdAt).toISOString()])];const csv=rows.map(r=>r.map(v=>'"'+String(v??"").replaceAll('"','""')+'"').join(",")).join("\\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="one-bite-orders.csv";a.click();URL.revokeObjectURL(a.href);};
$("year").textContent=new Date().getFullYear();
renderMenu();renderCart();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(console.warn));